package com.lily.teacup.base_class;

/**
 * 结果对象解析基类
 */
public class TAPBean {
}
