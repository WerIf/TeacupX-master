package com.lily.teacup.fragment_bridge;

public abstract class BridgeNoParamNoResult extends BaseBridge {

    public BridgeNoParamNoResult(String name) {
        super(name);
    }

    public abstract void bridge();
}
