package com.lily.teacup.basicclass;

class BaseBean {
}
