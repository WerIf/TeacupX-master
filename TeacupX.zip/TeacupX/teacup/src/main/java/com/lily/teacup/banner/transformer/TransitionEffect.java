package com.lily.teacup.banner.transformer;

public enum TransitionEffect {
    Default,
    Alpha,
    Rotate,
    Cube,
    Flip,
    Accordion,
    ZoomFade,
    Fade,
    ZoomCenter,
    ZoomStack,
    Stack,
    Depth,
    Zoom
}