package com.lily.teacup.banner.transformer;


import android.view.View;

public class DefaultPageTransformer extends TAPPageTransformer {

    @Override
    public void handleInvisiblePage(View view, float position) {
    }

    @Override
    public void handleLeftPage(View view, float position) {
    }

    @Override
    public void handleRightPage(View view, float position) {
    }

}