package com.lily.teacup.base_class;

/**
 * 网络请求 基类
 */
public class TAPHttp {
}
