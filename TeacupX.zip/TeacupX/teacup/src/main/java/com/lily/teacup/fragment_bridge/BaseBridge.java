package com.lily.teacup.fragment_bridge;

public abstract class BaseBridge {

    public BaseBridge(String name){
        this.interfaceName=name;
    }

    public String interfaceName;

}
